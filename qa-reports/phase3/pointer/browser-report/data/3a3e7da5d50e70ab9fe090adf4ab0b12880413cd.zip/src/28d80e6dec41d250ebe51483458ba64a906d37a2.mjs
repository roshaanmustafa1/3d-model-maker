import { test, expect } from '@playwright/test'
import { directory, setup, open, product, save, scene, record } from '../../../scripts/qa/phase3-support.mjs'

test('Phase 3 pointer movement updates layer coordinates and actual texture pixels', async ({ page }) => {
  test.setTimeout(120000); page.setDefaultTimeout(15000)
  const events = await setup(page)
  await open(page)
  await product(page, 'Streetwear Oversized Tee')
  await page.getByRole('button', { name: 'Artwork', exact: true }).click()
  await page.getByTitle('Rectangle', { exact: true }).click()
  const before = await save(page), textureBefore = await scene(page)
  const canvas = page.locator('.konvajs-content').first(), bounds = await canvas.boundingBox()
  await page.mouse.move(bounds.x + 230, bounds.y + 230)
  const started = Date.now()
  const telemetry = await page.evaluate(() => {
    const mesh = window.__qaSceneObjects().find(o => o.isMesh && o.name === 'Body_Main')
    const renderer = mesh.__r3f.root.getState().gl
    const gl = renderer.getContext(), extension = gl.getExtension('WEBGL_debug_renderer_info')
    return { frame: renderer.info.render.frame, time: performance.now(), gpu: extension && gl.getParameter(extension.UNMASKED_RENDERER_WEBGL) }
  })
  await page.mouse.down()
  await page.mouse.move(bounds.x + 270, bounds.y + 250, { steps: 20 })
  await page.mouse.up()
  const after = await save(page)
  await page.waitForTimeout(1500)
  const textureAfter = await scene(page)
  const rendering = await page.evaluate(() => {
    const mesh = window.__qaSceneObjects().find(o => o.isMesh && o.name === 'Body_Main')
    return { frame: mesh.__r3f.root.getState().gl.info.render.frame, time: performance.now() }
  })
  await page.mouse.click(bounds.x + 20, bounds.y + 20)
  const deselected = await page.getByText('No Layer Selected', { exact: true }).isVisible()
  await record('pointer-drag', { before, after, textureBefore, textureAfter, durationMs: Date.now() - started, telemetry, rendering, rendererFps: (rendering.frame - telemetry.frame) * 1000 / (rendering.time - telemetry.time), deselected, events })
  await page.screenshot({ path: `${directory}/screenshots/pointer-drag.png` })
  expect.soft(after.customization.zones.body_front.layers[0].x).not.toBe(before.customization.zones.body_front.layers[0].x)
  expect.soft(textureAfter.meshes[0].materials[0].texture.hash).not.toBe(textureBefore.meshes[0].materials[0].texture.hash)
  expect.soft(deselected).toBe(true)
})
