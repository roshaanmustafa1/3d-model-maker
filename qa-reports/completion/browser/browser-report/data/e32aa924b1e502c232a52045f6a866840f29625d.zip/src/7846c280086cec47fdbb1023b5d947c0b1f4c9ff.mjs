import { test, expect } from '@playwright/test'
import { mkdir } from 'node:fs/promises'
import { observeReactScenes } from './observer.mjs'

test.beforeEach(async ({ page }) => {
  await mkdir('qa-reports/completion/screenshots', { recursive: true })
  await page.addInitScript(observeReactScenes)
  await page.goto('/')
  await expect(page.getByRole('button', { name: 'Import', exact: true })).toBeVisible()
})

test('Completion: local generated GLB inspection and Studio handoff require no generation provider', async ({ page }) => {
  await page.getByRole('button', { name: /AI Generator|AI Image/i }).click()
  await expect(page.getByText('Local AI GLB handoff', { exact: true })).toBeVisible()
  await page.getByLabel('Generated GLB file').setInputFiles('docs/fixtures/black-shirt.glb')
  await expect(page.getByRole('button', { name: 'Open in Modeling Studio', exact: true })).toBeEnabled()
  await page.screenshot({ path: 'qa-reports/completion/screenshots/local-handoff.png' })
  await page.getByRole('button', { name: 'Open in Modeling Studio', exact: true }).click()
  await expect.poll(() => page.evaluate(() => window.__qaSnapshot().meshes.length)).toBeGreaterThan(0)
  await expect(page.getByText('AI Image-to-3D Studio & Asset Pipeline')).toHaveCount(0)
})

test('Completion: material split, undo/redo, UV packing and durable save use actual controls', async ({ page }) => {
  await page.getByRole('button', { name: 'Import', exact: true }).click()
  await page.locator('input[type=file][accept*=".glb"]').setInputFiles('qa-reports/phase3_5/fixtures/independent-slots.glb')
  await expect(page.getByRole('heading', { name: 'Import 3D Asset' })).toHaveCount(0)
  await page.getByText('QA_Material_Slots', { exact: true }).first().click()
  await page.getByRole('button', { name: 'Geom', exact: true }).click()
  const before = await page.evaluate(() => window.__qaSnapshot().meshes.filter(mesh => mesh.name.startsWith('QA_Material_Slots')).reduce((sum, mesh) => sum + mesh.triangles, 0))
  await page.getByRole('button', { name: 'Split by material', exact: true }).click()
  await expect(page.getByText('QA_Material_Slots_Part1', { exact: true }).first()).toBeVisible()
  await expect(page.getByText('QA_Material_Slots_Part2', { exact: true }).first()).toBeVisible()
  await expect.poll(() => page.evaluate(() => window.__qaSnapshot().meshes.filter(mesh => mesh.name.startsWith('QA_Material_Slots')).reduce((sum, mesh) => sum + mesh.triangles, 0))).toBe(before)
  await page.getByTitle('Undo (Ctrl+Z)', { exact: true }).click()
  await expect(page.getByText('QA_Material_Slots', { exact: true }).first()).toBeVisible()
  await page.getByTitle('Redo (Ctrl+Y)', { exact: true }).click()
  await page.getByRole('button', { name: 'UV', exact: true }).click()
  await page.getByRole('button', { name: 'Pack UV islands', exact: true }).click()
  await page.screenshot({ path: 'qa-reports/completion/screenshots/split-uv-preparation.png' })
  await page.getByRole('button', { name: 'Save', exact: true }).click()
  await expect(page.getByText('Project saved to IndexedDB', { exact: true })).toBeVisible()
  await page.reload()
  await page.getByRole('button', { name: 'File', exact: true }).click()
  await page.getByRole('menuitem', { name: /^Open:/ }).first().click()
  await expect(page.getByText('QA_Material_Slots_Part1', { exact: true }).first()).toBeVisible()
  await expect(page.getByText('QA_Material_Slots_Part2', { exact: true }).first()).toBeVisible()
})
